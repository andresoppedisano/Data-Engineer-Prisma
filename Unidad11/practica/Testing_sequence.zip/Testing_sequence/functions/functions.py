# Funciones.

def get_hola()-> str:
    return 'hola'

def get_mundo ()-> str:
    return 'mundo'

def get_valid_word()-> str:
    valid_word = get_hola() + ' ' + get_mundo()
    return valid_word
